using StudentServiceLib;

namespace _520H0672_Quan
{
    [TestClass]
    public class StudentTest
    {
        [TestMethod]
        public void TestCase1()
        {
            Student st = new Student();
            st.Score = 8.5;
            char letter = st.getLetterScore();
            Assert.AreEqual('A', letter);
        }
        [TestMethod]
        public void TestCase2()
        {
            Student st = new Student();
            st.Score = 8;
            char letter = st.getLetterScore();
            Assert.AreEqual('A', letter);
        }
        [TestMethod]
        public void TestCase3()
        {
            Student st = new Student();
            st.Score = 7;
            char letter = st.getLetterScore();
            Assert.AreEqual('C', letter);
        }
        [TestMethod]
        public void TestCase4()
        {
            Student st = new Student();
            st.Score = 5;
            char letter = st.getLetterScore();
            Assert.AreEqual('D', letter);
        }

    }
}